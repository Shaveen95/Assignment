package sc95.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringbootDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
