package sc95.springboot.topiccontroller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TopicService  {
	
	@Autowired
	private TopicRepo topicRepo;
	
	public List<Topics> getAllTopics(){
		//return topics;
		List<Topics> topics = new ArrayList<>();
		topicRepo.findAll()
		.forEach(topics::add);
		return topics;
	}
	
	public Optional<Topics> getTopic(String id) {
		//return topics.stream().filter(t -> t.getId().equals(id)).findFirst().get();
		return topicRepo.findById(id);
	}

	public void addTopic(Topics topics2) {
		// TODO Auto-generated method stub
		topicRepo.save(topics2);
	}

	public void updateTopic(String id, Topics topics2) {
		// TODO Auto-generated method stub
		topicRepo.save(topics2);
	}

	public void deleteTopic(String id) {
		topicRepo.deleteById(id);
		
	}
}

