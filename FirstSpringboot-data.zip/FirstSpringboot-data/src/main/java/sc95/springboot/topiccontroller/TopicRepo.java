package sc95.springboot.topiccontroller;

import org.springframework.data.repository.CrudRepository;

public interface TopicRepo extends CrudRepository<Topics, String> {

}
